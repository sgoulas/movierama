export { default } from "./Movies";
