export { default } from "./Poster";
