export { default } from "./Movie";
