export { default } from "./SimilarMovies";
