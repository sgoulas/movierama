export { default } from "./Trailer";
