export const CURRENTLY_PLAYING_ENDPOINT = "/movie/now_playing";
export const SEARCH_MOVIE = "/search/movie";
export const GENRE_LIST = "/genre/movie/list";
