const token = "bc50218d91157b1ba4f142ef7baaa6a0";

export default token;
