export {
  fetchCurrentlyPlayingMovies,
  searchMovie,
  fetchGenreList,
  fetchMovieReviews,
  fetchSimilarMovies,
  fetchMovieTrailers,
} from "./fetchFunctions";
