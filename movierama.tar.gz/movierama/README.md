# movierama

This is my technical assignment as part of my interview process for the position of front end developer at Workable.
